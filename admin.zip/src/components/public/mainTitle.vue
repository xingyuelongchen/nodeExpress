<template>
    <div class="main-title">
        <div>
            <span
                v-show="value"
                @click="()=>$router.go(-1)"
                class="my-icon icon-left text-active title"
            ></span>
            <span>{{$route.meta.title}}</span>
        </div>
        <div v-show="value">
            <el-button size="small" @click="event(false)">取消</el-button>
            <el-button size="small" @click="event(true)">确认</el-button>
        </div>
    </div>
</template>

<script>
export default {
    props: {
        value: {
            type: null,
            default: null
        }
    },
    methods: {
        event(e) {
            this.$emit("input", {
                source: "title",
                event: e
            });
        }
    }
};
</script>

<style lang="less" scoped>
.main-title {
    height: 75px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #fff;
    padding: 0 40px;
    font-family: PingFangSC-Semibold;
    font-size: 26px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 1px;
    color: #323235;
    .title {
        display: inline-block;
        vertical-align: middle;
        width: 50px;
        margin-right: 30px;
        border-right: 1px solid #e6e6e6;
    }
}
</style>