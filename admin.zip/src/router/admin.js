export default {
    // 企业管理后台路由
    path: '/', component: () => import('@/pages/organization/index.vue'),
    children: [
        // 后台首页
        {

            path: 'dashboard',
            name: 'dashboard',
            meta: {
                title: '企业首页',
            },
            component: () => import('@/pages/organization/dashboard/index.vue'),
        },
        // 企业管理
        {
            meta: {
                title: '企业管理',
            },
            path: 'manage',
            name: 'manage',
            component: () => import('@/pages/organization/manage/index.vue'),
            children: [
                {
                    meta: {
                        title: '轮播图',
                    },
                    path: 'sideShow',
                    name: 'sideShow',
                    component: () => import('@/pages/organization/manage/sideShow.vue'),
                }, {
                    meta: {
                        title: '员工',
                    },
                    path: 'member_list',
                    name: 'member_list',
                    component: () => import('@/pages/organization/manage/memberList.vue')
                },
                {
                    meta: {
                        title: '公告',
                    },
                    path: 'announcements',
                    name: 'announcements',
                    component: () => import('@/pages/organization/manage/announcements.vue')
                },
                {
                    meta: {
                        title: '留言管理',
                    },
                    path: 'message',
                    name: 'message',
                    component: () => import('@/pages/organization/manage/message.vue')
                }
            ]
        },
        // 活动管理
        {
            meta: {
                title: '活动管理',
            },
            path: 'events',
            name: 'events',
            component: () => import('@/pages/organization/events/index.vue'),
            children: [
                {
                    meta: {
                        title: '活动',
                    },
                    path: 'event',
                    name: 'event',
                    component: () => import('@/pages/organization/events/event.vue')
                },
                {
                    meta: {
                        title: '参与签到',
                    },
                    path: 'activitysign',
                    name: 'activitySign',
                    component: () => import('@/pages/organization/events/activitySign.vue')
                },
                {
                    meta: {
                        title: '分类管理',
                    },
                    path: 'class',
                    name: 'activityClass',
                    component: () => import('@/pages/organization/events/activityClass.vue')
                }
            ]
        },
        // 文章管理
        {
            meta: {
                title: '文章管理',
            },
            path: 'articles',
            name: 'articles',
            component: () => import('@/pages/organization/articles/index.vue'),
            children: [
                {
                    meta: {
                        title: '文章',
                    },
                    path: 'article',
                    name: 'article',
                    component: () => import('@/pages/organization/articles/article.vue'),
                },
                {
                    meta: {
                        title: '分类',
                    },
                    path: 'article_class',
                    name: 'article_class',
                    component: () => import('@/pages/organization/articles/articleClass.vue')

                }
            ]
        },
        // 客户管理
        {
            meta: {
                title: '客户管理',
            },
            path: 'member',
            name: 'menber',
            component: () => import('@/pages/organization/menber/index.vue'),
            children: [
                {
                    meta: {
                        title: '客户',
                    },
                    path: 'menber_manage',
                    name: 'menber_manage',
                    component: () => import('@/pages/organization/menber/menberManage.vue')
                },
                {
                    meta: {
                        title: '分组',
                    },
                    path: 'menber_class',
                    name: 'menber_class',
                    component: () => import('@/pages/organization/menber/menberClass.vue')
                }
            ]
        },
        // 订单管理
        {
            meta: {
                title: '订单管理',
            },
            path: 'order',
            name: 'order',
            component: () => import('@/pages/organization/order/index.vue')
        },
        // 设置
        {
            meta: {
                title: '设置',
            },
            path: 'setting',
            name: 'setting',
            component: () => import('@/pages/organization/setting/index.vue')
        }
    ]
}
