<template>
    <div class="articleClass">{{msg}}</div>
</template>  
<script>
export default {
    data() {
        return {
            msg: "articleClass"
        };
    },
    methods: {}
};
</script> 
<style lang="less" scoped>
.articleClass {
    background: #fff;
}
</style>  