<template>
    <div class="menberClass">{{msg}}</div>
</template>  
<script>
export default {
    data() {
        return {
            msg: "menberClass"
        };
    },
    methods: {}
};
</script> 
<style lang="less" scoped>
.menberClass {
    background: #fff;
}
</style>  