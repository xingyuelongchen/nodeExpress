<template>
    <div class="menberManage">{{msg}}</div>
</template>  
<script>
export default {
    data() {
        return {
            msg: "menberManage"
        };
    },
    methods: {}
};
</script> 
<style lang="less" scoped>
.menberManage {
    background: #fff;
}
</style>  