<template>
<div class="setting">
  {{msg}}
  
</div>  
</template>  
<script> 
   export default { 
      data(){
         return{
             msg:'setting'
          }
      },
      methods:{
        
      }
    } 
</script> 
<style lang="less" scoped>
.setting{
background:#fff;
}
</style>  