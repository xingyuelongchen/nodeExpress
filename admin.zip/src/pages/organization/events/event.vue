<template>
<div class="event">
  {{msg}}
  
</div>  
</template>  
<script> 
   export default { 
      data(){
         return{
             msg:'event'
          }
      },
      methods:{
        
      }
    } 
</script> 
<style lang="less" scoped>
.event{
background:#fff;
}
</style>  