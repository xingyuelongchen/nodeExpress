<template>
<div class="memberList">
  {{msg}}
  
</div>  
</template>  
<script> 
   export default { 
      data(){
         return{
             msg:'memberList'
          }
      },
      methods:{
        
      }
    } 
</script> 
<style lang="less" scoped>
.memberList{
background:#fff;
}
</style>  