<template>
<div class="announcements">
  {{msg}}
  
</div>  
</template>  
<script> 
   export default { 
      data(){
         return{
             msg:'announcements'
          }
      },
      methods:{
        
      }
    } 
</script> 
<style lang="less" scoped>
.announcements{
background:#fff;
}
</style>  