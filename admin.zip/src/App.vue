<template>
    <div id="app">
        <router-view />
    </div>
</template>

<style lang="less">
body,
html {
    padding: 0;
    margin: 0;
}
#app {
    font-family: PingFangSC-Semibold, "Avenir", Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #323235;
}
#nav {
    padding: 30px;
    a {
        font-weight: bold;
        color: #2c3e50;
        &.router-link-exact-active {
            color: #42b983;
        }
    }
}
</style>
