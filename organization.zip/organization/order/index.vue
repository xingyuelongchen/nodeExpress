<template>
<div class="order">
  {{msg}}
  
</div>  
</template>  
<script> 
   export default { 
      data(){
         return{
             msg:'order'
          }
      },
      methods:{
        
      }
    } 
</script> 
<style lang="less" scoped>
.order{
background:#fff;
}
</style>  