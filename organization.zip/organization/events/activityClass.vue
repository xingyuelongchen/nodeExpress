<template>
<div class="class">
  {{msg}}
  
</div>  
</template>  
<script> 
   export default { 
      data(){
         return{
             msg:'class'
          }
      },
      methods:{
        
      }
    } 
</script> 
<style lang="less" scoped>
.class{
background:#fff;
}
</style>  