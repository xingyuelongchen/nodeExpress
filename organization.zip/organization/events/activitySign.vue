<template>
<div class="sign">
  {{msg}}
  
</div>  
</template>  
<script> 
   export default { 
      data(){
         return{
             msg:'sign'
          }
      },
      methods:{
        
      }
    } 
</script> 
<style lang="less" scoped>
.sign{
background:#fff;
}
</style>  