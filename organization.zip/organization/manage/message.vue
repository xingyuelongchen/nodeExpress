<template>
  <div class="message">
    <mainTitle v-model="input" />
    <div style="overflow:auto;height:90%" v-if="!input">
      <div class="title">
        <el-input
          v-model="search"
          size="small"
          @input="onSearch"
          suffix-icon="el-icon-search"
          placeholder="请输入搜索内容"
        />
        <!-- <el-button type="primary" icon="el-icon-refresh" size="small" @click.stop="event">同步</el-button> -->
      </div>
      <div class="table-title table-row">
        <span>标题</span>
        <span>联系人</span>
        <span>发布时间</span>
        <span>联系电话</span>
        <span>状态</span>
      </div>

      <div class="table-item" v-for="(e,i) in sort " :key="i">
        <div class="table-row">
          <template v-for="v in 4">
            <!-- <el-tooltip class="item" effect="light" :key="v" :content="v+''" placement="left"> -->
            <span :key="v" :title="v">{{e}}</span>
            <!-- </el-tooltip> -->
          </template>
          <span>
            <span @click="input=true" class="text-active" v-if="e">未回复</span>
            <span style="color: #838eab;" v-else>已回复</span>
          </span>
        </div>
      </div>
      <div class="table-page" v-if="sort.length>10">
        <el-pagination background layout="prev, pager, next" :total="sort.length"></el-pagination>
      </div>
    </div>
    <div v-else class="save">asdadasd</div>
  </div>
</template>  
<script>
export default {
  components: {
    mainTitle: () => import("@/components/public/mainTitle.vue")
  },
  data() {
    return {
      input: false,
      search: "",
      arr: ["a", "李", 3, 4],
      sort: []
    };
  },
  mounted() {
    this.sort = this.arr;
  },
  methods: {
    onSearch() {
      console.log("员工搜索");
    },
    event() {
      console.log("同步");
    }
  }
};
</script> 
<style lang="less" scoped>
.message {
  height: 100%;
  .title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 40px;
    .el-input {
      width: 300px;
    }
  }
  .table-title {
    padding: 0 40px;
    font-family: PingFangSC-Semibold;
    font-size: 16px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: #323235;
    font-weight: bold;
  }
  .table-item {
    padding: 0 40px;
    font-family: PingFangSC-Regular;
    font-size: 16px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: #323235;
    &:hover,
    &.active {
      box-shadow: 0px 0px 10px 0px rgba(131, 142, 171, 0.2);
      background: #fff;
      cursor: pointer;
    }
  }
  .table-page {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100px;
  }
  .table-row {
    border-bottom: 1px solid #e6ebf1;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    > span {
      height: 53px;
      line-height: 53px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      &:first-child {
        flex: 5;
      }
      &:nth-child(2) {
        flex: 2;
      }
      &:nth-child(3) {
        flex: 2;
      }
      &:nth-child(4) {
        flex: 2;
      }
      &:last-child {
        flex: 1;
        display: flex;
        justify-content: space-between;
      }
    }
  }
}
</style>  