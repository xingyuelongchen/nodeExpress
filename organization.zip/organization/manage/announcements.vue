<template>
  <div class="memberList">
    <mainTitle v-model="input" :btn="['取消','发送']" />
    <div style="overflow:auto;height:90%" v-if="!input">
      <div class="title">
        <el-input
          v-model="search"
          size="small"
          @input="onSearch"
          suffix-icon="el-icon-search"
          placeholder="请输入搜索内容"
        />
        <el-button type="primary" size="small" @click.stop="input=true">添加公告</el-button>
      </div>
      <div class="table-title">
        <div class="table-row">
          <span>标题 / 企业</span>
          <span>发布时间</span>
          <span>更新时间</span>
          <span>操作</span>
        </div>
      </div>

      <div class="table-item" v-for="e in sort " :key="e">
        <div class="table-row">
          <template v-for="v in 3">
            <!-- <el-tooltip class="item" effect="light" :key="v" :content="v+''" placement="left"> -->
            <span :key="v" :title="v">{{e}}</span>
            <!-- </el-tooltip> -->
          </template>
          <span>
            <span class="text-active">编辑</span>
            <span class="text-active">删除</span>
          </span>
        </div>
      </div>
      <div class="table-page" v-if="sort.length>10">
        <el-pagination background layout="prev, pager, next" :total="sort.length"></el-pagination>
      </div>
    </div>
    <div v-else class="save">
      <div>
        <div>标题</div>
        <el-input />
      </div>
      <div>
        <div>内容</div>
        <textarea id="editor" ref="editor" class="textarea"></textarea>
      </div>
    </div>
  </div>
</template>  
<script>
import CKeditor from "@ckeditor/ckeditor5-build-classic";
// 编辑器工具栏文本语言 zh-cn 是简体中文
import "@ckeditor/ckeditor5-build-classic/build/translations/zh-cn";
import "@ckeditor/ckeditor5-build-classic/build/translations/zh";
export default {
  components: {
    mainTitle: () => import("@/components/public/mainTitle.vue")
  },
  watch: {
    input(a) {
      console.log(a);
    }
  },
  data() {
    return {
      search: "", // 搜索框输入内容
      input: false, //开启标题栏 返回按钮
      arr: ["a", "李", 3, 4, 3, 4, 3, 4, 3, 4, 3, 4, 3, 4], //原始数据
      sort: [], //排序后的数据
      form: {
        title: "",
        editor: ""
      }
    };
  },
  mounted() {
    this.sort = this.arr;
    this.initCkeditor();
  },
  methods: {
    onSearch() {
      console.log("员工搜索");
    },
    event() {
      console.log("同步");
    },
    // 富文本插件 初始化
    initCkeditor() {
      let that = this;
      // 上传适配插件所有的操作都在这里面完成
      class myUploadLoader {
        constructor(loader) {
          this.loader = loader;
        }
        upload() {
          return this.loader.file.then(
            file =>
              new Promise((resolve, reject) => {
                let reader = new FileReader();
                reader.addEventListener(
                  "load",
                  function() {
                    console.log(reader.result);
                    resolve({
                      default: reader.result
                    });
                  },
                  false
                );
                reader.readAsDataURL(file);

                // 这里面写的就是上传请求，只需要最终结果调用 resolve 方法
                // 并且返回一个至少包含 default : imgUrl 的对象,
                // 例如：{default:'http://abc.com/a/b.png'}
                // let formdata = new FormData();
                // formdata.append('file',file);
                // fetch(url,{
                //   method:'post',
                //   body:formdata
                // })
                // .then(response=>{
                //   // 后端至少返回上传图片的URL
                //   let url = response.url
                //   resolve({
                //     default: url
                //   });
                // })
                // .catch(err=>{
                //   reject(err)
                // })
              })
          );
        }
        abort() {}
      }
      function myUpload(e) {
        // 使用 CKeditor 提供的 API 修改上传适配器
        e.plugins.get("FileRepository").createUploadAdapter = loader =>
          new myUploadLoader(loader);
      }
      // 构建编辑器
      CKeditor.create(this.$refs.editor, {
        // 编辑器配置
        extraPlugins: [myUpload], // 添加自定义图片上传适配插件
        language: "zh-cn"
      })
        .then(e => {
          that.editor = e;
          // 每次修改都会触发更新 vm.data 里面的属性值
          e.model.document.on("change:data", () => {
            that.form.value = e.getData();
          });
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
};
</script> 


<style lang="less" scoped>
.memberList {
  height: 100%;
  .save {
    min-width: 635px;
    width: 42%;
    height: 55%;
    background: #fff;
    margin: 0 auto;
    margin-top: 4%;
    border-radius: 6px;
    padding: 40px;
    overflow-y: auto;
    overflow-x: hidden;
    > div {
      margin-top: 30px;
    }
    .editor {
      height: 60%;
      min-height: 200px;
    }
  }
  .title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 40px;
    .el-input {
      width: 300px;
    }
  }
  .table-title {
    padding: 0 40px;
    font-family: PingFangSC-Semibold;
    font-size: 16px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: #323235;
    font-weight: bold;
  }
  .table-item {
    padding: 0 40px;
    font-family: PingFangSC-Regular;
    font-size: 16px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: #323235;
    &:hover,
    &.active {
      box-shadow: 0px 0px 10px 0px rgba(131, 142, 171, 0.2);
      background: #fff;
      cursor: pointer;
    }
  }
  .table-page {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100px;
  }
  .table-row {
    border-bottom: 1px solid #e6ebf1;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    > span {
      height: 53px;
      line-height: 53px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      &:first-child {
        flex: 5;
      }
      &:nth-child(2) {
        flex: 2;
      }
      &:nth-child(3) {
        flex: 2;
      }
      &:last-child {
        flex: 1;
        display: flex;
        justify-content: space-between;
      }
    }
  }
}
</style>  