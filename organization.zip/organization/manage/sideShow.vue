<template>
  <div class="siderShowindex">
    <mainTitle v-model="input" @input="event" />
    <div style="overflow:auto;height:100%">
      <el-container class="index-content">
        <div class="imgList">
          <vuedraggable v-model="arr" v-bind="options" tag="div">
            <transition-group type="transition" name="flip-list">
              <template>
                <div v-for="v in arr " :key="v">
                  <div class="imgItem">
                    <div class="img">
                      <el-image
                        src="https://fuss10.elemecdn.com/e/5d/4a731a90594a4af544c0c25941171jpeg.jpeg"
                        lazy
                        fit="cover"
                      >
                        <div slot="error" class="image-slot">
                          <i class="el-icon-picture-outline"></i>
                        </div>
                      </el-image>
                    </div>
                    <div class="tool">
                      <div>a</div>
                      <div>b</div>
                    </div>
                    <div class="title">title</div>
                  </div>
                </div>
                <div key="a">
                  <div class="add-img text-active" @click="addImgShow = true">
                    <i class="my-icon icon-add"></i>
                    <el-dialog
                      custom-class="mw3"
                      :visible="addImgShow"
                      width="30%"
                      center
                      :show-close="false"
                      :append-to-body="true"
                    >
                      <div slot="title" class="aaa">
                        <div class="my-icon icon-close btn-active" @click.stop="event('close')"></div>
                        <div>title</div>
                        <div class="my-icon icon-gou btn-active" @click.stop="event('save')"></div>
                      </div>
                      <div class="bbb">
                        <div
                          @click.stop="$refs.addfile.click"
                          v-if="!form.base"
                          class="my-icon icon-add addfile"
                        >点击上传图片</div>
                        <div v-else class="fileshow">
                          <el-image :src="form.base" lazy fit="fill"></el-image>
                        </div>
                        <input
                          type="file"
                          style="display:none"
                          ref="addfile"
                          @change.stop="event('addfile')"
                        />
                      </div>
                      <div class="ccc">
                        <div>
                          <div>标题</div>
                          <el-input v-model="form.title" placeholder="请输入内容"></el-input>
                        </div>
                        <div>
                          <div>标题</div>
                          <el-input v-model="form.url" placeholder="请输入内容"></el-input>
                        </div>
                        <div>
                          <div>标题</div>
                          <el-input v-model="form.sortId" placeholder="请输入内容"></el-input>
                        </div>
                      </div>
                    </el-dialog>
                  </div>
                </div>
              </template>
            </transition-group>
          </vuedraggable>
        </div>
      </el-container>
    </div>
  </div>
</template>  
<script>
import vuedraggable from "vuedraggable";
export default {
  components: {
    mainTitle: () => import("@/components/public/mainTitle.vue"),
    vuedraggable
  },
  data() {
    return {
      input: null,
      addImgShow: false,
      arr: [1, 2, 3, 4],
      options: {
        group: "addSideImg",
        animation: 0,
        disabled: false,
        ghostClass: "ghost",
        filter: ".add-img"
      },
      form: {
        title: "",
        url: "",
        sortId: "",
        file: true,
        base: null
      }
    };
  },
  methods: {
    event(e) {
      console.log("sideshow ", e);
      if (e == "addfile" && this.$refs.addfile.files.length) {
        this.form.file == this.$refs.addfile.files[0];
        this.handlerChange(this.$refs.addfile);
      }
      if (e == "close") {
        this.addImgShow = false;
        this.form = {
          title: "",
          url: "",
          sortId: "",
          file: true,
          base: null
        };
      }
    },
    // 生成本地预览URL
    handlerChange(e) {
      let file = e.files[0],
        url = null;
      if (window.createObjectURL != undefined) {
        // basic
        url = window.createObjectURL(file);
      } else if (window.webkitURL != undefined) {
        // webkit or chrome
        url = window.webkitURL.createObjectURL(file);
      } else if (window.URL != undefined) {
        // mozilla(firefox)
        url = window.URL.createObjectURL(file);
      }
      this.form.base = url;
    }
  }
};
</script> 
<style lang="less">
.mw3 {
  min-width: 300px;
}
.flip-list-move {
  transition: transform 0.5s;
}
.el-dialog {
  border-radius: 6px;
  overflow: auto;
  background: #f6f9fc;
  .aaa {
    display: flex;
    justify-content: space-around;
    align-items: center;
    height: 84px;
    background: #fff;
    font-size: 26px;
    color: #323235;
    margin: -20px -20px 0;
    > div:not(:nth-child(2)) {
      width: 60px;
      height: 34px;
      font-size: 20px;
      color: #838eab;
      background: #e6ebf1;
      border-radius: 6px;
      line-height: 34px;
      text-align: center;
      //   &:hover{
      //       background:#276667;
      //       color:#fff;
      //   }
    }
  }
  .bbb {
    height: 200px;
    background: #fff;
    border-radius: 6px;
    .addfile {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
      height: 200px;
    }
    .fileshow {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100%;
      overflow: hidden;
    }
  }
  .ccc {
    > div {
      margin: 17px 0;
    }
  }
}
.siderShowindex {
  height: 100%;
  .index-content {
    margin-bottom: 85px;
    .imgList {
      width: 100%;
      > div {
        > span {
          padding: 0 20px;
          display: flex;
          justify-content: flex-start;
          align-items: center;
          flex-wrap: wrap;
          > div {
            max-width: 296px;
            max-height: 296px;
            min-width: 200px;
            min-height: 200px;
            width: 18%;
            margin: 0.6%;
            border-radius: 6px;
            .imgItem:hover {
              &:after {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: #32b0b350;
                content: "拖动调整顺序";
                cursor: pointer;
                text-align: center;
                line-height: 296px;
                color: #fff;
                font-size: 16px;
              }
            }
            .imgItem {
              width: 100%;
              position: relative;
              background: #ccc;
              border-radius: 6px;
              overflow: hidden;
              padding-top: 100%;
              > div {
                position: absolute;
                &.img {
                  top: 0;
                  left: 0;
                  width: 100%;
                  height: 100%;
                  margin: auto;
                  .el-image {
                    width: 100%;
                    height: 100%;
                  }
                }
                &.tool {
                  width: 100%;
                  top: 0;
                  left: 0;
                  display: flex;
                  justify-content: space-between;
                }
                &.title {
                  width: 100%;
                  height: 20%;
                  bottom: 0;
                  left: 0;
                  background: rgba(0, 0, 0, 0.2);
                }
              }
            }
            .add-img {
              width: 100%;
              border-radius: 6px;
              overflow: hidden;
              padding-top: 100%;
              background: transparent;
              color: #838eab;
              border: 1px dashed #838eab;
              display: -ms-flexbox;
              -ms-flex-pack: center;
              -ms-flex-align: center;
              font-size: 56px;
              position: relative;
              > i {
                position: absolute;
                top: 50%;
                left: 0;
                right: 0;
                margin: auto;
                text-align: center;
                margin-top: -28px;
              }
            }
          }
        }
      }
    }
  }
}
</style>  