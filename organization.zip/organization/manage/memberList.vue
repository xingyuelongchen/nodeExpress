<template>
  <div class="memberList">
    <mainTitle />
    <div style="overflow:auto;height:90%">
      <div class="title">
        <el-input v-model="search" size="small" @input="onSearch" suffix-icon="el-icon-search" placeholder="请输入搜索内容" />
        <el-button type="primary" icon="el-icon-refresh" size="small" @click.stop="event">同步</el-button>
      </div>
      <div class="table-title table-row">
        <span>姓氏</span>
        <span>名字</span>
        <span>编号</span>
        <span>职位</span>
        <span>联系方式</span>
        <span>邮箱</span>
      </div>

      <div class="table-item" v-for="e in sort " :key="e">
        <div class="table-row">
          <template v-for="v in 6">
            <!-- <el-tooltip class="item" effect="light" :key="v" :content="v+''" placement="left"> -->
            <span :key="v" :title="v">{{e}}</span>
            <!-- </el-tooltip> -->
          </template>
        </div>
      </div>
      <div class="table-page" v-if="sort.length>10">
        <el-pagination background layout="prev, pager, next" :total="sort.length"></el-pagination>
      </div>
    </div>
  </div>
</template>  
<script>
export default {
  components: {
    mainTitle: () => import("@/components/public/mainTitle.vue")
  },
  data() {
    return {
      search: "",
      arr: ["a", "李", 3, 4],
      sort: []
    };
  },
  mounted() {
    this.sort = this.arr;
  },
  methods: {
    onSearch() {
      console.log("员工搜索");
    },
    event() {
      console.log("同步");
    }
  }
};
</script> 
<style lang="less" scoped>
.memberList {
  height: 100%;
  .title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 40px;
    .el-input {
      width: 300px;
    }
  }
  .table-title {
    padding: 0 40px;
    font-family: PingFangSC-Semibold;
    font-size: 16px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: #323235;
    font-weight: bold;
  }
  .table-item {
    padding: 0 40px;
    font-family: PingFangSC-Regular;
    font-size: 16px;
    font-weight: normal;
    font-stretch: normal;
    letter-spacing: 0px;
    color: #323235;
    &:hover,
    &.active {
      box-shadow: 0px 0px 10px 0px rgba(131, 142, 171, 0.2);
      background: #fff;
      cursor: pointer;
    }
  }
  .table-page {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100px;
  }
  .table-row {
    border-bottom: 1px solid #e6ebf1;
    display: flex;
    justify-content: flex-start;
    align-items: center;
    > span {
      min-width: 140px;
      max-width: 250px;
      height: 53px;
      line-height: 53px;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      &:first-child {
        max-width: 150px;
      }
    }
  }
}
</style>  