<template>
<div class="article">
  {{msg}}
  
</div>  
</template>  
<script> 
   export default { 
      data(){
         return{
             msg:'article'
          }
      },
      methods:{
        
      }
    } 
</script> 
<style lang="less" scoped>
.article{
background:#fff;
}
</style>  